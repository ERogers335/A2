
/**
 * This gets customer info
 *
 * @author Evan 
 * @version 1.0
 */
public class Customer
{
    // instance variables - replace the example below with your own
    private String LN;
    private String FN;
    private String company;
    private String addy;
    private String city;
    private String state;
    private String zip;
    private String phone;

    /**
     * Constructor for objects of class Customer
     */
    public Customer(String LN, String FN, String company, String addy, String city, String state, String zip, String phone)
    {
        this.LN = LN;
        this.FN = FN;
        this.company = company;
        this.addy = addy;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.phone = phone;
    }
    
    public void designChoice(int designChoice){
        int choice = designChoice;
        
        if(choice > 5) {
            System.out.println("You must use a number between 1 and 5");
        } else if (choice == 1) {
            System.out.println("You chose option 1. Your total is: $400");
        } else if (choice == 2) {
            System.out.println("You chose option 2. Your total is: $550");
        } else if (choice == 3) {
            System.out.println("You chose option 3. Your total is: $625");
        } else if (choice == 4) {
            System.out.println("You chose option 4. Your total is: $1,030");
        }else if (choice == 5) {
            System.out.println("You chose option 5. Your total is: $2,000");
            }
        }
}
