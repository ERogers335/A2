import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class is for taking the information and
 * printing individual items.
 *
 * @author Evan R
 * @version 1.0
 * 
 */

public class Book
{
    // instance variables - replace the example below with your own
    private String firstN;
    private String lastN;
    private String ISBN;
    private String name;
    private String dateOfRelease;
    private int pages;
    
    /**
     * Constructor for objects of class Book
     */
    public Book(String lastN, String firstN, String ISBN, String name, String dateOfRelease, int pages)
    {
        // initialise instance variables
        this.firstN = firstN;
        this.lastN = lastN;
        this.ISBN = ISBN;
        this.name = name;
        this.dateOfRelease = dateOfRelease;
        this.pages = pages;
    }
    
    public void printLN(){
        System.out.println("Last Name: " + lastN);
    }
    
    public void printFN(){
        System.out.println("First Name: " + firstN);
    }
    
    public void printISBN() {
        System.out.println("ISBN Rating: " + ISBN);
    }
    
    public void printName(){
        System.out.println("Name of Book: " + name);
    }
    
    public void printDateOfRelease(){
        System.out.println("Release Date: " + dateOfRelease);
    }
    
    public void updatePages(int numOfPages){
        pages = numOfPages;
    }
    
    public void printPages(){
        if(pages > 10){
            System.out.println("Pages: " + pages);
        } else {
            System.out.println("Page number must be higher than 10! Re enter page number");
        }
    }
}

