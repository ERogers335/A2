import java.util.ArrayList;
import java.util.List;
/**
 * This is supposed to be a class to print the book details but
 * I can't figure out how to do it.
 *
 * @author Evan R.
 * @version 1.0
 */
public class BookPrinter
{
    // instance variables - replace the example below with your own
    /**
     * Constructor for objects of class BookPrinter
     */
    public BookPrinter(String lastN, String firstN, String ISBN, String name, String dateOfRelease, String pages)
    {
        // initialise instance variables
        
    }
    
    public void printLN(String lastN) {
        System.out.println("Last Name: " + lastN);
    }
}
